package com.sap.cloud.iot.java;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.Base64;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.sap.security.core.server.csi.IXSSEncoder;
import com.sap.security.core.server.csi.XSSEncoder;

//import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;
/**
 * Servlet implementing a simple JDBC based persistence sample application for
 * SAP HANA Cloud Platform.
 */
public class IoTServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(IoTServlet.class);

	private TemperatureDAO temperatureDAO;

	/** {@inheritDoc} */
	@Override
	public void init() throws ServletException {
		try {
			InitialContext ctx = new InitialContext();
			DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/DefaultDB");
			temperatureDAO = new TemperatureDAO(ds);
		} catch (SQLException e) {
			throw new ServletException(e);
		} catch (NamingException e) {
			throw new ServletException(e);
		}
	}

	/** {@inheritDoc} */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		try {
			appendTemperatureTable(response);
			workOrderECC(response);
			// appendAddForm(response);
		} catch (Exception e) {
			response.getWriter().println("Persistence operation failed with reason: " + e.getMessage());
			LOGGER.error("Persistence operation failed", e);
		}
	}

	/** {@inheritDoc} */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			
			doGet(request, response);
		} catch (Exception e) {
			response.getWriter().println("Persistence operation failed with reason: " + e.getMessage());
			LOGGER.error("Persistence operation failed", e);
		}
	}

	private void appendTemperatureTable(HttpServletResponse response) throws SQLException, IOException {
		// Append table that lists all persons
		List<Temperature> resultList = temperatureDAO.selectAllTemperature();
		response.getWriter().println("<h1>IoT - Cloud for Service Client</H1>");
		response.getWriter().println("<p><table border=\"1\"><tr><th colspan=\"3\">"
				+ (resultList.isEmpty() ? "" : resultList.size() + " ") + "Entries in the IoT HCP Database</th></tr>");
		if (resultList.isEmpty()) {
			response.getWriter().println("<tr><td colspan=\"3\">Database is empty</td></tr>");
		} else {
			response.getWriter().println("<tr><th>TimeStamp</th><th>Device</th><th>Temperature</th></tr>");
		}
		IXSSEncoder xssEncoder = XSSEncoder.getInstance();
		for (Temperature p : resultList) {
			String Tstamp;
			SimpleDateFormat formatter;

			formatter = new SimpleDateFormat("yyyy.MM.dd 'at' hh:mm:ss z");
			Tstamp = formatter.format(p.getTimestamp());
			response.getWriter().println("<tr><td>" + xssEncoder.encodeHTML(Tstamp) + "</td><td>"
					+ xssEncoder.encodeHTML(p.getDevice()) + "</td><td>" + p.getTemp() + "</td></tr>");
		}
		response.getWriter().println("</table></p>");

		for (Temperature p : resultList) {
			Temperature pTemp = new Temperature();
			pTemp.setTimestamp(p.getTimestamp());
			pTemp.setTemp(p.getTemp());
			pTemp.setDevice(p.getDevice());
			String Tstamp;
			String Temperature;
			SimpleDateFormat formatter;
			formatter = new SimpleDateFormat("yyyy.MM.dd 'at' hh:mm:ss z");
			Tstamp = formatter.format(p.getTimestamp());
			Temperature = p.getTemp().toString();
			try {
				response.getWriter().println("Initialing Request to C4C");
				// Create SOAP Connection
				SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
				SOAPConnection soapConnection = soapConnectionFactory.createConnection();

				// Send SOAP Message to SOAP Server
				String url = "https://my304456.crm.ondemand.com/sap/bc/srt/scs/sap/manageservicerequestin1?sap-vhost=my304456.crm.ondemand.com";
				// SOAPMessage soapReq = createSOAPRequest(Tstamp,Audio);
				MessageFactory messageFactory = MessageFactory.newInstance();
				SOAPMessage soapMessage = messageFactory.createMessage();
				SOAPPart soapPart = soapMessage.getSOAPPart();
				String soapAction = "http://sap.com/xi/A1S/Global/ManageServiceRequestIn/MaintainBundleRequest";
				String serverURI = "http://sap.com/xi/SAPGlobal20/Global";

				// SOAP Envelope
				SOAPEnvelope envelope = soapPart.getEnvelope();
				envelope.addNamespaceDeclaration("glob", serverURI);

				// SOAP Body
				SOAPBody soapBody = envelope.getBody();
				SOAPElement ElemService = soapBody.addChildElement("ServiceRequestBundleMaintainRequest2_sync", "glob");
				SOAPElement soapBodyElemBM = ElemService.addChildElement("BasicMessageHeader");
				SOAPElement ElemBMUUID = soapBodyElemBM.addChildElement("UUID");
				ElemBMUUID.addTextNode(java.util.UUID.randomUUID().toString());
				SOAPElement soapBodySerReq = ElemService.addChildElement("ServiceRequest");
				Name AttrActionCode = envelope.createName("actionCode");
				soapBodySerReq.addAttribute(AttrActionCode, "01");
				SOAPElement ElemName = soapBodySerReq.addChildElement("Name");
				DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
				Date date = new Date();
				String tdate = dateFormat.format(date);
				ElemName.addTextNode("IoT Ticket Instance " + Tstamp);
				SOAPElement ElemDataOrigTCode = soapBodySerReq.addChildElement("DataOriginTypeCode");
				ElemDataOrigTCode.addTextNode("4");
				SOAPElement ElemBuyerParty = soapBodySerReq.addChildElement("BuyerParty");
				Name AttrContPartyListTran = envelope.createName("contactPartyListCompleteTransmissionIndicator");
				ElemBuyerParty.addAttribute(AttrContPartyListTran, "true");
				SOAPElement ElemBPid = ElemBuyerParty.addChildElement("BusinessPartnerInternalID");
				ElemBPid.addTextNode("1001020");
				SOAPElement ElemText = soapBodySerReq.addChildElement("Text");
				SOAPElement ElemTCode = ElemText.addChildElement("TypeCode");
				ElemTCode.addTextNode("10004");
				SOAPElement ElemContent = ElemText.addChildElement("Content");
				ElemContent.addTextNode("Device exceeded Temperature threshold of 25 Centigrade, The Actual Value was: "
						+ Temperature + "Centigrade - Generated on: " + Tstamp);

				MimeHeaders headers = soapMessage.getMimeHeaders();
				headers.addHeader("SOAPAction", soapAction);

				headers.addHeader("Authorization", "Basic X0hDUDpWaWtpQDEyMw==");
				soapMessage.saveChanges();

				/* Print the request message */

				response.getWriter().println("Request SOAP Message = ");
				response.getWriter().println(soapMessage.toString());

				SOAPMessage soapResponse = soapConnection.call(soapMessage, url);
				if (soapResponse != null) {
					response.getWriter().println("Received Resonse from C4C");
				}
				soapConnection.close();
				// Process the SOAP Response
				// printSOAPResponse(soapResponse);
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				Source sourceContent = soapResponse.getSOAPPart().getContent();
				// System.out.print("\nResponse SOAP Message = ");
				response.getWriter().println("\nResponse SOAP Message = ");
				// StreamResult result = new StreamResult(System.out);
				StreamResult result = new StreamResult(response.getWriter());
				transformer.transform(sourceContent, result);

				// reading XML Response
				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				DocumentBuilder builder;
				InputSource is;
				try {
					builder = factory.newDocumentBuilder();
					// is = new InputSource(new StringReader(xmlop));
					// Document doc = builder.parse(is);
					Document doc = soapResponse.getSOAPBody().extractContentAsDocument();
					NodeList list = doc.getElementsByTagName("ID");
					pTemp.setTkt(list.item(0).getTextContent());
					// updating the Ticket in DataBase
					if (!pTemp.getTkt().isEmpty()) {
						System.out.println("C4C ID:" + list.item(0).getTextContent());
						response.getWriter().println("\n TimeStamp: " + pTemp.getTimestamp().toString() + " C4C ID:"
								+ list.item(0).getTextContent());
						try {
							temperatureDAO.updateTemperature(pTemp);
						} catch (Exception e) {
							response.getWriter().println("Persistence operation failed with reason: " + e.getMessage());
							LOGGER.error("Persistence operation failed", e);
						}
					}

				} catch (ParserConfigurationException e) {
				} catch (IOException e) {
				}

			} catch (Exception e) {
				response.getWriter().println("Error occurred while sending SOAP Request to Server");
				e.printStackTrace();
			}
		}
	}

	/**
     * Create ECC PM Order based on threshold.
     */
	private void workOrderECC(HttpServletResponse response) throws SQLException, IOException {
		// Append table that lists all persons
		List<motor> resultList = temperatureDAO.selectAllmotor();
		response.getWriter().println("<h1>IoT - ECC Client</H1>");
		response.getWriter().println("<p><table border=\"1\"><tr><th colspan=\"3\">"
				+ (resultList.isEmpty() ? "" : resultList.size() + " ") + "Entries in the IoT HCP Database for motor</th></tr>");
		if (resultList.isEmpty()) {
			response.getWriter().println("<tr><td colspan=\"3\">Database is empty</td></tr>");
		} else {
			response.getWriter().println("<tr><th>TimeStamp</th><th>Device</th><th>Revolutions</th></tr>");
		}
		IXSSEncoder xssEncoder = XSSEncoder.getInstance();
		for (motor p : resultList) {
			String Tstamp;
			SimpleDateFormat formatter;

			formatter = new SimpleDateFormat("yyyy.MM.dd 'at' hh:mm:ss z");
			Tstamp = formatter.format(p.getTimestamp());
			response.getWriter().println("<tr><td>" + xssEncoder.encodeHTML(Tstamp) + "</td><td>"
					+ xssEncoder.encodeHTML(p.getMachine()) + "</td><td>" + p.getRevolutions() + "</td></tr>");
		}
		response.getWriter().println("</table></p>");

		for (motor p : resultList) {
			motor pTemp = new motor();
			pTemp.setTimestamp(p.getTimestamp());
			pTemp.setRevolutions(p.getRevolutions());
			pTemp.setMachine(p.getMachine());
			String Tstamp;
			String Revolutions;
			SimpleDateFormat formatter;
			formatter = new SimpleDateFormat("yyyy.MM.dd 'at' hh:mm:ss z");
			Tstamp = formatter.format(p.getTimestamp());
			Revolutions = p.getRevolutions().toString();
			ThresholdDAO TDAO = new ThresholdDAO();
			String Priority = "NA";
			try {
				response.getWriter().println("Initialing Request to ECC");
				// Create SOAP Connection
				SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
				SOAPConnection soapConnection = soapConnectionFactory.createConnection();

				// Send SOAP Message to SOAP Server
	            String url = "http://cgawssap20.cgawssapuk.com:8001/sap/bc/srt/rfc/sap/zws_bapi_alm_order_maintain_v2/812/zws_bapi_alm_order_maintain_v2/zws_bapi_alm_order_maintain_v2";
				// SOAPMessage soapReq = createSOAPRequest(Tstamp,Audio);
				
	            MessageFactory messageFactory = MessageFactory.newInstance();
	            SOAPMessage soapMessage = messageFactory.createMessage();
	            SOAPPart soapPart = soapMessage.getSOAPPart();
	            String soapAction = "http://cgawssap20.cgawssapuk.com:8001/sap/bc/srt/rfc/sap/zws_bapi_alm_order_maintain_v2/812/zws_bapi_alm_order_maintain_v2/zws_bapi_alm_order_maintain_v2";
	            String serverURI = "urn:sap-com:document:sap:soap:functions:mc-style";

	            // SOAP Envelope
	            SOAPEnvelope envelope = soapPart.getEnvelope();
	            envelope.addNamespaceDeclaration("urn", serverURI);

	            // SOAP Body
	            SOAPBody soapBody = envelope.getBody();
	            SOAPElement ElemService = soapBody.addChildElement("ZpmBapiAlmOrderMaintain","urn");
	            SOAPElement ElemBStart = ElemService.addChildElement("IBasicStart");
	            DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
	            //Date date = new Date();
	            String ttime = dateFormat.format(pTemp.getTimestamp());
	            ElemBStart.addTextNode(ttime);
	            
	            SOAPElement ElemDID = ElemService.addChildElement("IDeviceId");
	            //int rand = ThreadLocalRandom.current().nextInt(4000,5000);
	            
	            Priority = TDAO.GetPriority(pTemp.getRevolutions());
	            ElemDID.addTextNode(pTemp.getMachine() + "#" + pTemp.getRevolutions().toString() + "#" + Priority);
	            
	            SOAPElement ElemMDate = ElemService.addChildElement("IMalDate");
	            DateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
	            //Date date1 = new Date();
	            String tdate = dateFormat1.format(pTemp.getTimestamp());
	            ElemMDate.addTextNode(tdate);
	            
	           
	            soapMessage.saveChanges();

				/* Print the request message */

				response.getWriter().println("Request SOAP Message = ");
				response.getWriter().println(soapMessage.toString());

				SOAPMessage soapResponse = soapConnection.call(soapMessage, url);
				if (soapResponse != null) {
					response.getWriter().println("Received Resonse from ECC");
				}
				soapConnection.close();
				// Process the SOAP Response
				// printSOAPResponse(soapResponse);
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				Source sourceContent = soapResponse.getSOAPPart().getContent();
				// System.out.print("\nResponse SOAP Message = ");
				response.getWriter().println("\nResponse SOAP Message = ");
				// StreamResult result = new StreamResult(System.out);
				StreamResult result = new StreamResult(response.getWriter());
				transformer.transform(sourceContent, result);

				// reading XML Response
				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				DocumentBuilder builder;
				InputSource is;
				try {
					builder = factory.newDocumentBuilder();
					// is = new InputSource(new StringReader(xmlop));
					// Document doc = builder.parse(is);
					Document doc = soapResponse.getSOAPBody().extractContentAsDocument();
					NodeList list = doc.getElementsByTagName("EAufnrIn");
					pTemp.setTicket(list.item(0).getTextContent() + "-" + Priority);
					// updating the Ticket in DataBase
					if (!pTemp.getTicket().isEmpty()) {
						System.out.println("ECC Order ID:" + list.item(0).getTextContent());
						response.getWriter().println("\n TimeStamp: " + pTemp.getTimestamp().toString() + " ECC ID:"
								+ list.item(0).getTextContent());
						try {
							temperatureDAO.updateMotor(pTemp);
						} catch (Exception e) {
							response.getWriter().println("Persistence operation failed with reason: " + e.getMessage());
							LOGGER.error("Persistence operation failed", e);
						}
					}

				} catch (ParserConfigurationException e) {
				} catch (IOException e) {
				}

			} catch (Exception e) {
				response.getWriter().println("Error occurred while sending SOAP Request to Server");
				e.printStackTrace();
			}
		}
	}

	
	
	



	private static SOAPMessage createSOAPRequest(String Tstamp, String Audio) throws Exception {
		MessageFactory messageFactory = MessageFactory.newInstance();
		SOAPMessage soapMessage = messageFactory.createMessage();
		SOAPPart soapPart = soapMessage.getSOAPPart();
		String soapAction = "http://sap.com/xi/A1S/Global/ManageServiceRequestIn/MaintainBundleRequest";
		String serverURI = "http://sap.com/xi/SAPGlobal20/Global";

		// SOAP Envelope
		SOAPEnvelope envelope = soapPart.getEnvelope();
		envelope.addNamespaceDeclaration("glob", serverURI);

		/*
		 * Constructed SOAP Request Message: <SOAP-ENV:Envelope
		 * xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"
		 * xmlns:example="http://ws.cdyne.com/"> <SOAP-ENV:Header/>
		 * <SOAP-ENV:Body> <example:VerifyEmail>
		 * <example:email>mutantninja@gmail.com</example:email>
		 * <example:LicenseKey>123</example:LicenseKey> </example:VerifyEmail>
		 * </SOAP-ENV:Body> </SOAP-ENV:Envelope>
		 */

		// SOAP Body
		SOAPBody soapBody = envelope.getBody();
		SOAPElement ElemService = soapBody.addChildElement("ServiceRequestBundleMaintainRequest2_sync", "glob");
		SOAPElement soapBodyElemBM = ElemService.addChildElement("BasicMessageHeader");
		SOAPElement ElemBMUUID = soapBodyElemBM.addChildElement("UUID");
		ElemBMUUID.addTextNode(java.util.UUID.randomUUID().toString());
		SOAPElement soapBodySerReq = ElemService.addChildElement("ServiceRequest");
		Name AttrActionCode = envelope.createName("actionCode");
		soapBodySerReq.addAttribute(AttrActionCode, "01");
		SOAPElement ElemName = soapBodySerReq.addChildElement("Name");
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date = new Date();
		String tdate = dateFormat.format(date);
		ElemName.addTextNode("IoT Ticket Instance " + Tstamp);
		SOAPElement ElemDataOrigTCode = soapBodySerReq.addChildElement("DataOriginTypeCode");
		ElemDataOrigTCode.addTextNode("4");
		SOAPElement ElemBuyerParty = soapBodySerReq.addChildElement("BuyerParty");
		Name AttrContPartyListTran = envelope.createName("contactPartyListCompleteTransmissionIndicator");
		ElemBuyerParty.addAttribute(AttrContPartyListTran, "true");
		SOAPElement ElemBPid = ElemBuyerParty.addChildElement("BusinessPartnerInternalID");
		ElemBPid.addTextNode("1001020");
		SOAPElement ElemText = soapBodySerReq.addChildElement("Text");
		SOAPElement ElemTCode = ElemText.addChildElement("TypeCode");
		ElemTCode.addTextNode("10004");
		SOAPElement ElemContent = ElemText.addChildElement("Content");
		ElemContent.addTextNode("Device exceeded Temperature threshold of 0.4 decibel, The Actual Value was: <b>" + Audio
				+ "</b> decibel  Generated on: " + Tstamp);

		/*
		 * SOAPElement soapBodyElem1 = soapBodyElem.addChildElement("email",
		 * "example"); soapBodyElem1.addTextNode("vikidvg@gmail.com");
		 * SOAPElement soapBodyElem2 =
		 * soapBodyElem.addChildElement("LicenseKey", "example");
		 * soapBodyElem2.addTextNode("123");
		 */

		MimeHeaders headers = soapMessage.getMimeHeaders();
		headers.addHeader("SOAPAction", soapAction);
		String authorization = "_HCP" + ":" + "Viki@123";
		// byte[] encoded = Base64.encode(authorization.getBytes());
		// headers.addHeader("Authorization", "Basic " +
		// Base64.encode(authorization.getBytes()));
		headers.addHeader("Authorization", "Basic " + Base64.getEncoder().encodeToString(authorization.getBytes()));
		soapMessage.saveChanges();

		/* Print the request message */

		System.out.print("Request SOAP Message = ");
		soapMessage.writeTo(System.out);
		System.out.println();

		return soapMessage;
	}

}
