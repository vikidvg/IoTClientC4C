package com.sap.cloud.iot.java;

import java.util.Date;

/**
 * Class holding information on a person.
 */
public class Temperature {
  
    private Date C_TIMESTAMP;
    private String C_DEVICE;
    private Double C_TEMPERATURE;
    private String C_SERVTICKETID;
    
    public Date getTimestamp() {
        return C_TIMESTAMP;
    }

    public void setTimestamp(Date newtime) {
        this.C_TIMESTAMP = newtime;
    }
    
    public String getDevice() {
        return C_DEVICE;
    }

    public void setDevice(String newDevice) {
        this.C_DEVICE = newDevice;
    }
   
    public String getTkt() {
        return C_SERVTICKETID;
    }
    
    public void setTkt(String newTkt) {
        this.C_SERVTICKETID = newTkt;
    }
    public Double getTemp() {
        return C_TEMPERATURE;
    }

    public void setTemp(Double newTemp) {
        this.C_TEMPERATURE = newTemp;
    }
  
}
