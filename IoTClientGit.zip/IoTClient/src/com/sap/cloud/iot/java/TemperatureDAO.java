package com.sap.cloud.iot.java;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.sql.DataSource;



/**
 * Data access object encapsulating all JDBC operations for a Temperature and Motor.
 */
public class TemperatureDAO {
    private DataSource dataSource;

    /**
     * Create new data access object with data source.
     */
    public TemperatureDAO(DataSource newDataSource) throws SQLException {
        setDataSource(newDataSource);
    }

    /**
     * Get data source which is used for the database operations.
     */
    public DataSource getDataSource() {
        return dataSource;
    }

    /**
     * Set data source to be used for the database operations.
     */
    public void setDataSource(DataSource newDataSource) throws SQLException {
        this.dataSource = newDataSource;
        
    }

   

    /**
     * Update Temperature reading on the table with Service Ticket.
     */  
    public void updateTemperature(Temperature temperature) throws SQLException {
        Connection connection = dataSource.getConnection();

        try {
            PreparedStatement pstmt = connection
                    .prepareStatement("UPDATE NEO_5BKO3WD533K36KP05HRQKOF5N.T_IOT_1BD5043FC8BEF0468479  SET C_SERVTICKETID = ? WHERE C_TIMESTAMP = ? ");
            pstmt.setString(1, temperature.getTkt());
            pstmt.setTimestamp(2, new Timestamp(temperature.getTimestamp().getTime()));
            pstmt.executeUpdate();
        } finally {
            if (connection != null) {
                connection.close();
            }
        }
    }
    
    /**
     * Update Tachometer reading on the table with ECC PM Order.
     */  
    public void updateMotor(motor mot) throws SQLException {
        Connection connection = dataSource.getConnection();

        try {
            PreparedStatement pstmt = connection
                    .prepareStatement("UPDATE NEO_5BKO3WD533K36KP05HRQKOF5N.T_IOT_4E1AB35FA23102EEF23C  SET C_TICKET = ? WHERE C_TIMESTAMP = ? ");
            pstmt.setString(1, mot.getTicket());
            pstmt.setTimestamp(2, new Timestamp(mot.getTimestamp().getTime()));
            pstmt.executeUpdate();
        } finally {
            if (connection != null) {
                connection.close();
            }
        }
    }
    /**
     * Get all Temperature Reading from the table meeting the threshold. 
     */
    public List<Temperature> selectAllTemperature() throws SQLException,IOException {
    	String ODataURL = "https://jj6a7762c010.hana.ondemand.com:443/UKGeneric/services.xsodata/ThresholdConfig(Scenario='Temperature',Id='1')";
        Connection connection = dataSource.getConnection();
        try {
        	
        	ThresholdDAO TDAO = new ThresholdDAO();
    		Threshold Thres = TDAO.OdataCall(ODataURL);
    		Double Tthres = Thres.getLow();
            PreparedStatement pstmt = connection
                    .prepareStatement("SELECT C_TIMESTAMP,C_TEMPERATURE,C_UOM,C_DEVICE FROM NEO_5BKO3WD533K36KP05HRQKOF5N.T_IOT_1BD5043FC8BEF0468479 WHERE G_CREATED > CURRENT_DATE and C_TEMPERATURE >= "+Tthres.toString()+" and C_SERVTICKETID = ''");
            ResultSet rs = pstmt.executeQuery();
            ArrayList<Temperature> list = new ArrayList<Temperature>();
            while (rs.next()) {
                Temperature p = new Temperature();
                p.setTimestamp(rs.getDate(1));
                p.setDevice(rs.getString(4));
                p.setTemp(rs.getDouble(2));
                list.add(p);
            }
            return list;
        } finally {
            if (connection != null) {
                connection.close();
            }
        }
    }

    
    /**
     * Get all tachometer reading from the table.
     */
    public List<motor> selectAllmotor() throws SQLException,IOException {
    	String ODataURL = "https://jj6a7762c010.hana.ondemand.com:443/UKGeneric/services.xsodata/ThresholdConfig(Scenario='Machine',Id='3')";
        Connection connection = dataSource.getConnection();
        try {
        	ThresholdDAO TDAO = new ThresholdDAO();
    		Threshold Thres = TDAO.OdataCall(ODataURL);
    		Double Mthres = Thres.getHigh();
            PreparedStatement pstmt = connection
                    .prepareStatement("SELECT C_TIMESTAMP,C_REVOLUTIONS,C_UOM,C_MACHINE FROM NEO_5BKO3WD533K36KP05HRQKOF5N.T_IOT_4E1AB35FA23102EEF23C WHERE G_CREATED > CURRENT_DATE and C_REVOLUTIONS <= "+Mthres.toString()+" and C_TICKET = ''");
            ResultSet rs = pstmt.executeQuery();
            ArrayList<motor> list = new ArrayList<motor>();
            while (rs.next()) {
                motor m = new motor();
                m.setTimestamp(rs.getDate(1));
                m.setRevolutions(rs.getDouble(2));
                m.setUoM(rs.getString(3));
                m.setMachine(rs.getString(4));
                list.add(m);
            }
            return list;
        } finally {
            if (connection != null) {
                connection.close();
            }
        }
    }
    
}
