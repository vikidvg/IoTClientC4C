package com.sap.cloud.iot.java;


public class Threshold {
private String Scenario;
private String ID;
private Double Low;
private Double High;
private String Priority;

public String getScenario() {
    return Scenario;
}

public void setScenario(String newScenario) {
    this.Scenario = newScenario;
}

public String getID() {
    return ID;
}

public void setID(String newID) {
    this.ID = newID;
}

public Double getLow() {
    return Low;
}

public void setLow(Double newLow) {
    this.Low = newLow;
}

public Double getHigh() {
    return High;
}

public void setHigh(Double newHigh) {
    this.High = newHigh;
}

public String getPriority() {
    return Priority;
}

public void setPriority(String newPriority) {
    this.Priority = newPriority;
}
}
