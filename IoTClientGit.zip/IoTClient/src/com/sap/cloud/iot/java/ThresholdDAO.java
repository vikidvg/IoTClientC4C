package com.sap.cloud.iot.java;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.sql.SQLException;

import javax.net.ssl.HttpsURLConnection;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;



public class ThresholdDAO {
	
	public Threshold OdataCall (String URLa)throws IOException
	{
		Threshold thres = new Threshold();
		HttpsURLConnection con;
		//String absURL = "https://jj6a7762c010.hana.ondemand.com:443/UKGeneric/services.xsodata/ThresholdConfig(Scenario='Temperature',Id='1')";
		  String absURL = URLa;
		URL absU = new URL(absURL);
		//URL absU = new URL("https://jj6a7762c010.hana.ondemand.com:443/UKGeneric/services.xsodata/ThresholdConfig(Scenario=%27Temperature%27,Id=%271%27)");
		con = (HttpsURLConnection) absU.openConnection();
		BufferedReader in;
		InputStream is;
		try{
		
		con.setRequestMethod("GET");
		con.setRequestProperty("Authorization", "Basic VEhSRVNDT05GSUdfVVNSOkluaXRpYWwx");
		con.setRequestProperty("Accept", "*/*");
		/*con.setConnectTimeout(6000);
		int timeout = con.getConnectTimeout();
		
		response.getWriter().println("Time Out:"+timeout);*/
		con.setDoOutput(true);
        con.connect();
        if(con.getResponseCode() >= 400){
        	//is = con.getErrorStream();
        	BufferedReader in1 = new BufferedReader(new InputStreamReader(con.getErrorStream()));
        	StringBuffer resp1 = new StringBuffer();
    		String line1;
    		while ((line1 = in1.readLine()) != null) {
    			resp1.append(line1);
    		}

    		String xml1 = resp1.toString();
    		//response.getWriter().println(xml1);
        } else {
            is = con.getInputStream();
        }
		in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		
		
		StringBuffer resp = new StringBuffer();
		String line;
		while ((line = in.readLine()) != null) {
			resp.append(line);
		}

		String xml = resp.toString();
		

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(new ByteArrayInputStream(xml.getBytes()));
			XPathFactory xpathFactory = XPathFactory.newInstance();
			XPath xpath = xpathFactory.newXPath();


			String Scenario;
			String ID;
			String Low;
			String High;
			String Priority;
			if (xml.contains("entry") == false) {
				//throw new Exception();
			} else {
				XPathExpression exp;
				exp = xpath.compile("/entry/content/properties/Scenario");
				Scenario = (String) exp.evaluate(doc, XPathConstants.STRING);
				thres.setScenario(Scenario);
				
				exp = xpath.compile("/entry/content/properties/Id");
				ID = (String) exp.evaluate(doc, XPathConstants.STRING);
				thres.setID(ID);
				
			    exp = xpath.compile("/entry/content/properties/Low");
				Low = (String) exp.evaluate(doc, XPathConstants.STRING);
				Double lo1= Double.parseDouble(Low);
				//getInfo(doc, xpath, "/feed/entry/content/properties/firstName", QueryParams.FIRSTNAME);
				//response.getWriter().println("Low:"+ lo1);
				thres.setLow(lo1);
				
				exp = xpath.compile("/entry/content/properties/High");
				High = (String) exp.evaluate(doc, XPathConstants.STRING);
				Double Hi1= Double.parseDouble(High);
				thres.setHigh(Hi1);
				
				exp = xpath.compile("/entry/content/properties/Priority");
				Priority = (String) exp.evaluate(doc, XPathConstants.STRING);
				thres.setPriority(Priority);
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally{
			if(con != null)
			{
				con.disconnect();
			}
		}
		
		return thres;
	}
	
	public String GetPriority(Double rotation)throws IOException
	{
	    String Priority = "NA";
	    
		
	    String URL1 = "https://jj6a7762c010.hana.ondemand.com:443/UKGeneric/services.xsodata/ThresholdConfig(Scenario='Machine',Id='1')";
	    Threshold Thres = this.OdataCall(URL1);
	    if(rotation >= Thres.getLow() && rotation <= Thres.getHigh())
	    {
	    	return Thres.getPriority();
	    }
	    String URL2 = "https://jj6a7762c010.hana.ondemand.com:443/UKGeneric/services.xsodata/ThresholdConfig(Scenario='Machine',Id='2')";
	    Threshold Thres1 = this.OdataCall(URL2);
	    if(rotation >= Thres1.getLow() && rotation <= Thres1.getHigh())
	    {
	    	return Thres1.getPriority();
	    }
	    String URL3 = "https://jj6a7762c010.hana.ondemand.com:443/UKGeneric/services.xsodata/ThresholdConfig(Scenario='Machine',Id='3')";
	    Threshold Thres2 = this.OdataCall(URL3);
	    if(rotation >= Thres2.getLow() && rotation <= Thres2.getHigh())
	    {
	    	return Thres2.getPriority();
	    }
	    return Priority;
	}

}
