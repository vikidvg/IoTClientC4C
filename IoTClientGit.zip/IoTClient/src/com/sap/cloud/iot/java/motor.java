/**
 * 
 */
package com.sap.cloud.iot.java;

import java.util.Date;

/**
 * @author Vikidvg
 *class for tachometer sensor
 */
public class motor {
	private Date C_TIMESTAMP;
    private Double C_REVOLUTIONS;
    private String C_UOM;
    private String C_MACHINE;
    private String C_TICKET;
    
    public Date getTimestamp() {
        return C_TIMESTAMP;
    }
    public void setTimestamp(Date newtime) {
        this.C_TIMESTAMP = newtime;
    }
    
    
    public Double getRevolutions() {
        return C_REVOLUTIONS;
    }
    public void setRevolutions(Double newRevol) {
        this.C_REVOLUTIONS = newRevol;
    }
    
    
    public String getUoM() {
        return C_UOM;
    }
    public void setUoM(String newUoM) {
        this.C_UOM = newUoM;
    }
    
    public String getMachine() {
        return C_MACHINE;
    }
    public void setMachine(String newMachine) {
        this.C_MACHINE = newMachine;
    }
    
    public String getTicket() {
        return C_TICKET;
    }
    public void setTicket(String newTicket) {
        this.C_TICKET = newTicket;
    }
}
